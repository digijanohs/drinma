"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Heart, Trash2, ShoppingBag } from "lucide-react";
import Link from "next/link";
import { useWishlistStore } from "@/store/wishlist";
import { useCartStore } from "@/store/cart";

export default function WishlistContent() {
  const { items, removeItem, clearAll } = useWishlistStore();
  const { addItem } = useCartStore();

  if (items.length === 0) {
    return (
      <section className="py-20">
        <div className="max-w-md mx-auto text-center px-4">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="w-24 h-24 mx-auto mb-6 rounded-full bg-red-50 flex items-center justify-center"
          >
            <Heart className="w-10 h-10 text-red-300" />
          </motion.div>
          <h2 className="text-2xl font-display font-bold text-gray-900 dark:text-gray-50 mb-2">
            No favorites yet
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Explore the menu and add the drinks you love to your list!
          </p>
          <Link
            href="/menu"
            className="inline-flex items-center gap-2 px-6 py-3 bg-brand-600 hover:bg-brand-700 text-white rounded-xl font-medium transition-colors"
          >
            <ShoppingBag className="w-4 h-4" />
            Explore the menu
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold text-gray-900 dark:text-gray-50">
              Favorite products
            </h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">{items.length} products</p>
          </div>
          <button
            onClick={clearAll}
            className="flex items-center gap-2 px-4 py-2 text-sm text-red-600 border border-red-200 rounded-full hover:bg-red-50 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Clear all
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {items.map((item) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm overflow-hidden hover:shadow-md transition-shadow"
              >
                <div className="aspect-[4/3] bg-gradient-to-br from-brand-100 to-cream-200 flex items-center justify-center relative">
                  <svg className="w-12 h-12 text-brand-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M17 8H7l1.5 12h7L17 8z"/><path d="M6 8h12l-.5-2H6.5L6 8z"/><circle cx="12" cy="14" r="1.5" fill="currentColor" stroke="none"/></svg>
                  <button
                    onClick={() => removeItem(item.id)}
                    className="absolute top-3 right-3 p-2 rounded-full bg-white/90 text-red-500 hover:bg-red-50 transition-colors"
                    aria-label="Remove from Favorites"
                  >
                    <Heart className="w-4 h-4 fill-red-500" />
                  </button>
                </div>
                <div className="p-4">
                  <Link href={`/menu/${item.slug}`} className="block">
                    <h3 className="font-semibold text-gray-900 dark:text-gray-50 hover:text-brand-600 transition-colors">
                      {item.name}
                    </h3>
                  </Link>
                  <p className="text-brand-600 font-bold mt-1">
                    {item.price.toLocaleString("vi-VN")}đ
                  </p>
                  <button
                    onClick={() =>
                      addItem({
                        productId: item.id,
                        name: item.name,
                        image: item.image || "",
                        size: "M",
                        quantity: 1,
                        sugarLevel: 100,
                        iceLevel: 100,
                        toppings: [],
                        basePrice: item.price,
                        toppingPrice: 0,
                      })
                    }
                    className="mt-3 w-full flex items-center justify-center gap-2 py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-sm font-medium transition-colors"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    Add to cart
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
