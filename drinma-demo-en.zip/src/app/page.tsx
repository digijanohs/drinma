import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import Hero from "@/components/Hero";

export const dynamic = "force-dynamic";
import ProductCard from "@/components/ProductCard";
import FeaturedSection from "@/components/FeaturedSection";
import Features from "@/components/Features";
import Testimonials from "@/components/Testimonials";
import LoyaltySection from "@/components/LoyaltySection";
import FlashSale from "@/components/FlashSale";
import QualityPromise from "@/components/QualityPromise";
import AppPromo from "@/components/AppPromo";
import Link from "next/link";
import Image from "next/image";

export default async function Home() {
  const bestSellers = await prisma.product.findMany({
    where: { isBestSeller: true, isAvailable: true },
    include: { category: true },
    take: 6,
  });

  const newProducts = await prisma.product.findMany({
    where: { isNew: true, isAvailable: true },
    include: { category: true },
    take: 4,
  });

  const categories = await prisma.category.findMany({
    where: { slug: { not: "topping" } },
    orderBy: { order: "asc" },
  });

  return (
    <>
      <Header />
      <CartDrawer />

      <main className="overflow-x-clip">
        <Hero />

        {/* Categories Section */}
        <section className="py-20 bg-white dark:bg-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-display font-bold text-gray-900 dark:text-gray-50">
                Explore categories
              </h2>
              <p className="text-gray-500 dark:text-gray-400 mt-2">
                A flavor for every taste
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {categories.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/menu?category=${cat.slug}`}
                  className="group relative rounded-2xl overflow-hidden aspect-square bg-cream-100 hover:shadow-lg transition-all"
                >
                  {cat.image && (
                    <Image
                      src={cat.image}
                      alt={cat.name}
                      fill
                      sizes="(max-width: 768px) 50vw, (max-width: 1280px) 33vw, 20vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent z-10" />
                  <div className="absolute bottom-0 left-0 right-0 p-4 z-20">
                    <h3 className="text-white font-semibold text-sm md:text-base">
                      {cat.name}
                    </h3>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <FlashSale />

        <Features />

        <FeaturedSection products={newProducts} />

        {/* Best Sellers */}
        <section className="py-20 bg-cream-50 dark:bg-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="text-3xl font-display font-bold text-gray-900 dark:text-gray-50">
                  Best Sellers
                </h2>
                <p className="text-gray-500 dark:text-gray-400 mt-2">
                  Customer favorites
                </p>
              </div>
              <Link
                href="/menu"
                className="text-brand-600 dark:text-brand-400 font-medium hover:text-brand-700 dark:hover:text-brand-300 transition-colors"
              >
                View all →
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {bestSellers.map((product, index) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        <Testimonials />

        <QualityPromise />

        <LoyaltySection />

        <AppPromo />

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-brand-600 to-brand-800 text-white">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
              Order today
            </h2>
            <p className="text-brand-100 text-lg mb-8">
              Free delivery on orders from 100.000đ within 5km
            </p>
            <Link
              href="/menu"
              className="inline-flex items-center px-8 py-4 bg-white text-brand-700 rounded-full font-semibold hover:bg-cream-100 transition-colors shadow-lg"
            >
              Order now
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
